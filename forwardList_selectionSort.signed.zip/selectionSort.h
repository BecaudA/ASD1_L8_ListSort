#ifndef selectionsort_h
#define selectionsort_h

#include "forwardListUtils.h"

template <class T>
void selectionSort(std::forward_list<T>& L) {
  using namespace std;
  
  auto j = L.before_begin();
  
  if(L.empty())
    return; 
  
  // Parcours la liste jusqu'à l'avant dernier élément
  while(next(next(j)) != L.end()) {
    auto iMin = j;
    auto i = next(j);
    
    // Cherche le plus petit élément parmis les élément non-triés 
    while(next(i) != L.end()) {
      if(*next(i) < *next(iMin)) {
         iMin = i;
      }
      i = next(i);
    }
    
    // Déplace le plus petit élément non-trié
    L.splice_after(j, L, iMin);
    std::cout << L << std::endl;
    
    j = next(j);
   
  }
}

#endif

#include "fizzy.h"
#include <cassert>
#include <iostream>

using std::forward_list;

void fizzBuzz(std::forward_list<int>& L,
              std::forward_list<int>& F,
              std::forward_list<int>& B,
              std::forward_list<int>& FB)
{
  assert(F.empty() and B.empty() and FB.empty());

auto itF  = F.before_begin();
auto itB  = B.before_begin();
auto itFB = FB.before_begin();

// Parcours forward_list<int> L jusqu'à la fin
for(auto itL = L.before_begin(); next(itL) != L.end();) {
   
   // Test multiple 3 et 5
   if(!(*next(itL) % 15)) {
      FB.splice_after(itFB, L, itL);
      itFB++;
   } 
   // Test multiple 5
   else if (!(*next(itL) % 5)) {
      B.splice_after(itB, L, itL);
      itB++;
   } 
   // Test multiple 3
   else if (!(*next(itL) % 3)) {
      F.splice_after(itF, L, itL);
      itF++;
   } 
   // Si multiple ni de 3 ni de 5 -> passe au suivant
   else {
      ++itL;
   }
}
}

#ifndef insertionsort_h
#define insertionsort_h

#include "listUtils.h"

template <class T>
void insertionSort(std::list<T>& L) {
  using namespace std;

  if(L.empty())
    return;
    
 auto k = next(L.begin());
 
 // Parcours le tableau
 while(k != L.end()) {
   auto i = k;
   
   // Cherche où placé le premier élément plus petit que k
   while(i != L.begin() && *k < *prev(i)) { 
      i = prev(i);
   }
   
   auto t = next(k);
   
   // Déplace k
   L.splice(i, L, k);
   cout << L << endl;
   
   k = t;
 }
  
}

#endif // insertionsort_h
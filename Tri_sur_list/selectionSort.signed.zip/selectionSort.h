
#ifndef selectionsort_h
#define selectionsort_h

#include "listUtils.h"

template <class T>
void selectionSort(std::list<T>& L) {

  auto j = L.begin();
  
  // Parcours la liste jusqu'à l'avant dernier élément
  while(j != prev(L.end())) {
    auto iMin = j;
    auto i = next(j);
    
    // Cherche le plus petit élément parmis les élément non-triés 
    while(i != L.end()) {
      if(*i < *iMin) {
      iMin = i;
    }
    i = next(i);
   }
   
   // Déplace l'élément le plus petit (iMin) des non-triés à la fin des éléments triés
   L.splice(j, L, iMin);
   std::cout << L << std::endl;
   
   // La recherche des éléments non-triés commence après iMin
   j = next(iMin);
   
  }
}

#endif